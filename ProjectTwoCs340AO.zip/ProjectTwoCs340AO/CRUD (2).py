from pymongo import MongoClient
from bson import ObjectId

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB."""

    def __init__(self, username, password):
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30041
        DB = 'AAC'
        COL = 'animals'

        self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """Insert a document into the collection."""
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"Insert Error: {e}")
                return False
        else:
            raise ValueError("Data parameter is empty")

    def read(self, query):
        """Query for document(s) from the collection."""
        if query is not None:
            try:
                cursor = self.collection.find(query)
                return list(cursor)
            except Exception as e:
                print(f"Read Error: {e}")
                return []
        else:
            raise ValueError("Query parameter is empty")

    def read_all(self):
        """Retrieve all documents from the collection."""
        try:
            return list(self.collection.find())
        except Exception as e:
            print(f"Read All Error: {e}")
            return []

    def update(self, query, update_data):
        """Update document(s) in the collection."""
        if query is not None and update_data is not None:
            try:
                result = self.collection.update_many(query, {'$set': update_data})
                return result.modified_count
            except Exception as e:
                print(f"Update Error: {e}")
                return 0
        else:
            raise ValueError("Query or update_data parameter is empty")

    def delete(self, query):
        """Remove document(s) from the collection."""
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"Delete Error: {e}")
                return 0
        else:
            raise ValueError("Query parameter is empty")

    def read_by_rescue_type(self, rescue_type):
        """Retrieve documents filtered by rescue type."""
        return list(self.collection.find({'rescue_type': rescue_type}))

    def read_by_breed(self, breed):
        """Retrieve documents filtered by breed."""
        return list(self.collection.find({'breed': breed}))

    def read_by_rescue_type_and_breed(self, rescue_type, breed):
        """Retrieve documents filtered by both rescue type and breed."""
        return list(self.collection.find({
            'rescue_type': rescue_type,
            'breed': breed
        }))








